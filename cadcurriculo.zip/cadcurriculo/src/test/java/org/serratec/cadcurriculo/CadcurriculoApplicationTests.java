package org.serratec.cadcurriculo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadcurriculoApplicationTests {

	@Test
	void contextLoads() {
	}

}
