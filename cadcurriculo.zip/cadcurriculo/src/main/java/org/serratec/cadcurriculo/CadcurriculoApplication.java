package org.serratec.cadcurriculo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadcurriculoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadcurriculoApplication.class, args);
	}

}
